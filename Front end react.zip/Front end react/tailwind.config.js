export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        kodigoBlue: '#3B82F6',
        kodigoPurple: '#8B5CF6',
      },
    },
  },
  plugins: [],
};