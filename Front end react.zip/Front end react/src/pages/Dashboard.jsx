import { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const [bootcamps, setBootcamps] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
    } else {
      axios.get('https://kodigo-api.vercel.app/api/bootcamps', {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(res => setBootcamps(res.data))
        .catch(() => setBootcamps([]));
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-indigo-700 mb-8">Dashboard de Bootcamps</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {bootcamps.map((b) => (
          <div key={b.id} className="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition transform hover:scale-105">
            <h2 className="text-xl font-semibold text-purple-600 mb-2">{b.title}</h2>
            <p className="text-gray-700">{b.description}</p>
            <p className="mt-2 text-sm font-medium text-indigo-500">Duración: {b.durationWeeks} semanas</p>
          </div>
        ))}
      </div>
    </div>
  );
}