import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [bootcamps, setBootcamps] = useState([]);

  useEffect(() => {
    axios.get('https://kodigo-api.vercel.app/api/bootcamps')
      .then(res => setBootcamps(res.data))
      .catch(() => setBootcamps([]));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
      <header className="p-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold">Kodigo Bootcamps</h1>
        <nav className="space-x-4">
          <Link to="/login" className="hover:underline">Login</Link>
          <Link to="/register" className="hover:underline">Registro</Link>
        </nav>
      </header>

      <section className="flex flex-col justify-center items-center text-center mt-10 px-4">
        <h2 className="text-5xl font-bold mb-4">Aprende con los mejores bootcamps en tecnología</h2>
        <p className="text-lg mb-6">Conviértete en desarrollador fullstack con nuestros programas intensivos</p>
        <a href="#bootcamps" className="bg-white text-indigo-700 font-semibold px-6 py-3 rounded-lg shadow hover:scale-105 transition">Ver Bootcamps</a>
      </section>

      <section id="bootcamps" className="bg-gray-50 text-gray-800 mt-16 p-8 rounded-t-3xl shadow-inner">
        <h3 className="text-3xl font-bold text-center mb-8">Nuestros Bootcamps</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {bootcamps.map((b) => (
            <div key={b.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-2xl transition transform hover:scale-105">
              <h4 className="text-xl font-semibold mb-2 text-indigo-600">{b.title}</h4>
              <p className="text-gray-600">{b.description}</p>
              <p className="mt-3 text-sm font-medium text-purple-600">Duración: {b.durationWeeks} semanas</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="mt-16 py-6 bg-indigo-700 text-center">
        <p>© {new Date().getFullYear()} Kodigo. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}