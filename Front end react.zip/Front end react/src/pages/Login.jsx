import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    try {
      const res = await axios.post('https://kodigo-api.vercel.app/api/login', data);
      localStorage.setItem('token', res.data.token);
      navigate('/dashboard');
    } catch (err) {
      alert('Error al iniciar sesión');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <form onSubmit={handleSubmit(onSubmit)} className="bg-white p-8 rounded-xl shadow-lg w-96">
        <h2 className="text-2xl font-bold text-center mb-6 text-indigo-700">Iniciar Sesión</h2>
        <input {...register('email')} type="email" placeholder="Correo electrónico" className="w-full p-3 mb-4 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
        <input {...register('password')} type="password" placeholder="Contraseña" className="w-full p-3 mb-4 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
        <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition">Entrar</button>
      </form>
    </div>
  );
}