import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    try {
      await axios.post('https://kodigo-api.vercel.app/api/users', data);
      alert('Usuario creado exitosamente');
      navigate('/login');
    } catch (err) {
      alert('Error al crear usuario');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <form onSubmit={handleSubmit(onSubmit)} className="bg-white p-8 rounded-xl shadow-lg w-96">
        <h2 className="text-2xl font-bold text-center mb-6 text-purple-700">Crear Cuenta</h2>
        <input {...register('name')} placeholder="Nombre completo" className="w-full p-3 mb-4 border rounded-lg focus:ring-2 focus:ring-purple-500" />
        <input {...register('email')} type="email" placeholder="Correo electrónico" className="w-full p-3 mb-4 border rounded-lg focus:ring-2 focus:ring-purple-500" />
        <input {...register('password')} type="password" placeholder="Contraseña" className="w-full p-3 mb-4 border rounded-lg focus:ring-2 focus:ring-purple-500" />
        <button className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-3 rounded-lg font-semibold hover:scale-105 transition">Registrarse</button>
      </form>
    </div>
  );
}